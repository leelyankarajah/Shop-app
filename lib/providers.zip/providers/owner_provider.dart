import 'package:flutter/material.dart';
import 'package:shop/models/product_model.dart';

class OwnerProvider extends ChangeNotifier {
  final List<ProductModel> _products = List.from(demoPopularProducts);
  int _visitors = 0;
  int _orders = 0;

  List<ProductModel> get products => List.unmodifiable(_products);
  int get visitors => _visitors;
  int get orders => _orders;

  void addProduct(ProductModel p) {
    _products.insert(0, p);
    notifyListeners();
  }

  void updateProduct(String id, {String? title, String? brand, String? image, double? price, int? stock, bool? available}) {
    final idx = _products.indexWhere((e) => e.id == id);
    if (idx >= 0) {
      final old = _products[idx];
      _products[idx] = ProductModel(
        id: old.id,
        image: image ?? old.image,
        brandName: brand ?? old.brandName,
        title: title ?? old.title,
        price: price ?? old.price,
        priceAfetDiscount: old.priceAfetDiscount,
        dicountpercent: old.dicountpercent,
        stock: stock ?? old.stock,
        available: available ?? old.available,
        ordersCount: old.ordersCount,
      );
      notifyListeners();
    }
  }

  void removeProduct(int index) {
    if (index >= 0 && index < _products.length) {
      _products.removeAt(index);
      notifyListeners();
    }
  }

  void incrementVisitors() {
    _visitors++;
    notifyListeners();
  }

  void addOrder(String productId, {int quantity = 1}) {
    final idx = _products.indexWhere((e) => e.id == productId);
    if (idx >= 0) {
      _products[idx].ordersCount += quantity;
      _orders += quantity;
      notifyListeners();
    }
  }
}
