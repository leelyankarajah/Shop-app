import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shop/providers/owner_provider.dart';
import 'package:shop/models/product_model.dart';

class OwnerDashboard extends StatefulWidget {
  const OwnerDashboard({Key? key}) : super(key: key);

  @override
  State<OwnerDashboard> createState() => _OwnerDashboardState();
}

class _OwnerDashboardState extends State<OwnerDashboard> with SingleTickerProviderStateMixin {
  late TabController _tabs;
  String _search = '';
  bool _grid = false;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  void _openAdd(BuildContext ctx) {
    showDialog(context: ctx, builder: (_) => const AddProductDialog());
  }

  @override
  Widget build(BuildContext context) {
    final owner = Provider.of<OwnerProvider>(context);
    final products = owner.products.where((p) {
      final q = _search.toLowerCase();
      return q.isEmpty || p.title.toLowerCase().contains(q) || p.brandName.toLowerCase().contains(q);
    }).toList();

    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: const Text('Shop Owner'),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: () => setState(() {})),
        ],
        bottom: TabBar(
          controller: _tabs,
          tabs: const [Tab(text: 'Products'), Tab(text: 'Visitors')],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openAdd(context),
        icon: const Icon(Icons.add),
        label: const Text('Add Product'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            // top stats
            Row(
              children: [
                _StatCard(title: 'Products', value: '${owner.products.length}', color: Colors.blue),
                const SizedBox(width: 8),
                _StatCard(title: 'Orders', value: '${owner.orders}', color: Colors.green),
                const SizedBox(width: 8),
                _StatCard(title: 'Visitors', value: '${owner.visitors}', color: Colors.orange),
              ],
            ),
            const SizedBox(height: 12),
            // search & view toggle
            Row(
              children: [
                Expanded(
                  child: TextField(
                    decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search products or brands'),
                    onChanged: (v) => setState(() => _search = v),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(icon: Icon(_grid ? Icons.view_list : Icons.grid_view), onPressed: () => setState(() => _grid = !_grid)),
              ],
            ),
            const SizedBox(height: 12),
            Expanded(
              child: TabBarView(
                controller: _tabs,
                children: [
                  // Products tab
                  _grid ? _ProductsGrid(products: products) : _ProductsList(products: products),
                  // Visitors tab (simple)
                  _VisitorsView(),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String title, value;
  final Color color;

  const _StatCard({required this.title, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), color: color.withOpacity(0.12)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: TextStyle(color: color.withOpacity(0.9), fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            Text(value, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color)),
          ],
        ),
      ),
    );
  }
}

class _ProductsList extends StatelessWidget {
  final List<ProductModel> products;

  const _ProductsList({required this.products});

  @override
  Widget build(BuildContext context) {
    final owner = Provider.of<OwnerProvider>(context, listen: false);
    return ListView.separated(
      itemCount: products.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (ctx, i) {
        final p = products[i];
        return Card(
          elevation: 2,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: ListTile(
            leading: ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.network(p.image, width: 64, height: 64, fit: BoxFit.cover)),
            title: Text(p.title, style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text('${p.brandName} • \$${p.price.toStringAsFixed(2)} • Stock: ${p.stock}'),
            trailing: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Switch(value: p.available, onChanged: (v) => owner.updateProduct(p.id, available: v)),
                IconButton(icon: const Icon(Icons.delete, color: Colors.redAccent), onPressed: () {
                  final idx = owner.products.indexWhere((e) => e.id == p.id);
                  if (idx >= 0) owner.removeProduct(idx);
                }),
              ],
            ),
            onTap: () => _showProductActions(context, p),
          ),
        );
      },
    );
  }

  void _showProductActions(BuildContext context, ProductModel p) {
    showModalBottomSheet(context: context, builder: (_) {
      return Padding(
        padding: const EdgeInsets.all(12.0),
        child: Wrap(
          children: [
            ListTile(leading: const Icon(Icons.edit), title: const Text('Edit'), onTap: () { Navigator.pop(context); _openEdit(context, p); }),
            ListTile(leading: const Icon(Icons.add_shopping_cart), title: const Text('Add Fake Order'), onTap: () { Navigator.pop(context); Provider.of<OwnerProvider>(context, listen: false).addOrder(p.id); }),
            ListTile(leading: const Icon(Icons.delete, color: Colors.red), title: const Text('Delete', style: TextStyle(color: Colors.red)), onTap: () { Navigator.pop(context); final idx = Provider.of<OwnerProvider>(context, listen: false).products.indexWhere((e) => e.id == p.id); if (idx>=0) Provider.of<OwnerProvider>(context, listen: false).removeProduct(idx); }),
          ],
        ),
      );
    });
  }

  void _openEdit(BuildContext context, ProductModel p) {
    showDialog(context: context, builder: (_) => EditProductDialog(product: p));
  }
}

class _ProductsGrid extends StatelessWidget {
  final List<ProductModel> products;
  const _ProductsGrid({required this.products});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 0.78, crossAxisSpacing: 8, mainAxisSpacing: 8),
      itemCount: products.length,
      itemBuilder: (ctx, i) {
        final p = products[i];
        return Container(
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 6, offset: Offset(0,4))]),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(borderRadius: const BorderRadius.only(topLeft: Radius.circular(12), topRight: Radius.circular(12)), child: Image.network(p.image, height: 110, width: double.infinity, fit: BoxFit.cover)),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(p.title, style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Text('\$${p.price.toStringAsFixed(2)} • Stock ${p.stock}', style: TextStyle(color: Colors.grey[700])),
                  const SizedBox(height: 8),
                  Row(children: [
                    Expanded(child: ElevatedButton(onPressed: () => _showGridActions(context, p), child: const Text('Manage'))),
                  ])
                ]),
              )
            ],
          ),
        );
      },
    );
  }

  void _showGridActions(BuildContext context, ProductModel p) {
    showModalBottomSheet(context: context, builder: (_) {
      return Padding(
        padding: const EdgeInsets.all(12.0),
        child: Wrap(children: [
          ListTile(leading: const Icon(Icons.edit), title: const Text('Edit'), onTap: () { Navigator.pop(context); showDialog(context: context, builder: (_) => EditProductDialog(product: p)); }),
          ListTile(leading: const Icon(Icons.add_shopping_cart), title: const Text('Add Fake Order'), onTap: () { Navigator.pop(context); Provider.of<OwnerProvider>(context, listen: false).addOrder(p.id); }),
        ]),
      );
    });
  }
}

class _VisitorsView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final owner = Provider.of<OwnerProvider>(context);
    return Center(child: Text('Total visitors: ${owner.visitors}\nTotal orders: ${owner.orders}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 18)));
  }
}

class AddProductDialog extends StatefulWidget {
  const AddProductDialog({Key? key}) : super(key: key);

  @override
  State<AddProductDialog> createState() => _AddProductDialogState();
}

class _AddProductDialogState extends State<AddProductDialog> {
  final _form = GlobalKey<FormState>();
  String title = '';
  String brand = '';
  String image = '';
  String price = '';
  String stock = '10';

  void _submit() {
    if (_form.currentState?.validate() ?? false) {
      _form.currentState?.save();
      final p = ProductModel(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        image: image.isNotEmpty
            ? image
            : 'https://images.unsplash.com/photo-1604908177522-6b0f3b8b3995?auto=format&fit=crop&w=800&q=80',
        title: title,
        brandName: brand,
        price: double.tryParse(price) ?? 0.0,
        stock: int.tryParse(stock) ?? 10,
      );
      Provider.of<OwnerProvider>(context, listen: false).addProduct(p);
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Add Product'),
      content: Form(
        key: _form,
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextFormField(decoration: const InputDecoration(labelText: 'Title'), onSaved: (v) => title = v ?? '', validator: (v) => (v ?? '').isNotEmpty ? null : 'Enter title'),
            TextFormField(decoration: const InputDecoration(labelText: 'Brand'), onSaved: (v) => brand = v ?? '', validator: (v) => (v ?? '').isNotEmpty ? null : 'Enter brand'),
            TextFormField(decoration: const InputDecoration(labelText: 'Image URL (optional)'), onSaved: (v) => image = v ?? ''),
            TextFormField(decoration: const InputDecoration(labelText: 'Price'), keyboardType: TextInputType.numberWithOptions(decimal: true), onSaved: (v) => price = v ?? '', validator: (v) => (v != null && double.tryParse(v) != null) ? null : 'Enter price'),
            TextFormField(decoration: const InputDecoration(labelText: 'Stock'), keyboardType: TextInputType.number, onSaved: (v) => stock = v ?? '10', validator: (v) => (v!=null && int.tryParse(v)!=null) ? null : 'Enter stock'),
          ]),
        ),
      ),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')), ElevatedButton(onPressed: _submit, child: const Text('Add'))],
    );
  }
}

class EditProductDialog extends StatefulWidget {
  final ProductModel product;
  const EditProductDialog({required this.product, Key? key}) : super(key: key);

  @override
  State<EditProductDialog> createState() => _EditProductDialogState();
}

class _EditProductDialogState extends State<EditProductDialog> {
  final _form = GlobalKey<FormState>();
  late String title, brand, image, price, stock;

  @override
  void initState() {
    super.initState();
    title = widget.product.title;
    brand = widget.product.brandName;
    image = widget.product.image;
    price = widget.product.price.toString();
    stock = widget.product.stock.toString();
  }

  void _submit() {
    if (_form.currentState?.validate() ?? false) {
      Provider.of<OwnerProvider>(context, listen: false).updateProduct(widget.product.id, title: title, brand: brand, image: image, price: double.tryParse(price), stock: int.tryParse(stock));
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Edit Product'),
      content: Form(
        key: _form,
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextFormField(initialValue: title, decoration: const InputDecoration(labelText: 'Title'), onChanged: (v) => title = v),
            TextFormField(initialValue: brand, decoration: const InputDecoration(labelText: 'Brand'), onChanged: (v) => brand = v),
            TextFormField(initialValue: image, decoration: const InputDecoration(labelText: 'Image URL'), onChanged: (v) => image = v),
            TextFormField(initialValue: price, decoration: const InputDecoration(labelText: 'Price'), keyboardType: TextInputType.numberWithOptions(decimal: true), onChanged: (v) => price = v),
            TextFormField(initialValue: stock, decoration: const InputDecoration(labelText: 'Stock'), keyboardType: TextInputType.number, onChanged: (v) => stock = v),
          ]),
        ),
      ),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')), ElevatedButton(onPressed: _submit, child: const Text('Save'))],
    );
  }
}
