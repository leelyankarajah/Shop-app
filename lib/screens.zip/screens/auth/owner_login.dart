import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shop/providers/owner_provider.dart';

class OwnerLoginScreen extends StatefulWidget {
  const OwnerLoginScreen({Key? key}) : super(key: key);

  @override
  State<OwnerLoginScreen> createState() => _OwnerLoginScreenState();
}

class _OwnerLoginScreenState extends State<OwnerLoginScreen> {
  final _formKey = GlobalKey<FormState>();
  String _email = '';
  String _password = '';

  void _loginAsOwner() {
    if (_formKey.currentState?.validate() ?? false) {
      _formKey.currentState?.save();
      // For demo: increment visitors and navigate to owner dashboard
      Provider.of<OwnerProvider>(context, listen: false).incrementVisitors();
      Navigator.pushReplacementNamed(context, 'owner_dashboard');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Shop Owner Login'), elevation: 0),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            const SizedBox(height: 12),
            const Text('Welcome back, Owner', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('Manage your store, products and visitors', style: TextStyle(color: Colors.grey)),
            const SizedBox(height: 24),
            Form(
              key: _formKey,
              child: Column(
                children: [
                  TextFormField(
                    decoration: const InputDecoration(labelText: 'Email'),
                    keyboardType: TextInputType.emailAddress,
                    validator: (v) => v != null && v.contains('@') ? null : 'Enter a valid email',
                    onSaved: (v) => _email = v ?? '',
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    decoration: const InputDecoration(labelText: 'Password'),
                    obscureText: true,
                    validator: (v) => (v != null && v.length >= 6) ? null : 'Password min 6 chars',
                    onSaved: (v) => _password = v ?? '',
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(onPressed: _loginAsOwner, child: const Text('Login as Owner')),
                  ),
                  const SizedBox(height: 8),
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Back'),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
