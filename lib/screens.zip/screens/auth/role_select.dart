import 'package:flutter/material.dart';
import 'package:shop/route/route_constants.dart';

class RoleSelectScreen extends StatelessWidget {
  const RoleSelectScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 20),
              const Text('Welcome', style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text('Are you a Customer or a Shop Owner?', style: TextStyle(fontSize: 16, color: Colors.grey)),
              const SizedBox(height: 32),
              Expanded(
                child: Column(
                  children: [
                    _RoleCard(
                      title: 'Customer',
                      subtitle: 'Browse products and place orders',
                      color: Colors.indigo.shade50,
                      onTap: () {
                        Navigator.pushNamed(context, logInScreenRoute);
                      },
                    ),
                    const SizedBox(height: 16),
                    _RoleCard(
                      title: 'Shop Owner',
                      subtitle: 'Manage your store, add products, view visitors',
                      color: Colors.orange.shade50,
                      onTap: () {
                        Navigator.pushNamed(context, 'owner_login');
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Align(
                alignment: Alignment.center,
                child: TextButton(
                  onPressed: () => Navigator.pushNamed(context, signUpScreenRoute),
                  child: const Text('Create an account'),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}

class _RoleCard extends StatelessWidget {
  final String title, subtitle;
  final Color color;
  final VoidCallback onTap;

  const _RoleCard({required this.title, required this.subtitle, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 6, offset: Offset(0,4))],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(subtitle, style: const TextStyle(color: Colors.grey)),
          ],
        ),
      ),
    );
  }
}
